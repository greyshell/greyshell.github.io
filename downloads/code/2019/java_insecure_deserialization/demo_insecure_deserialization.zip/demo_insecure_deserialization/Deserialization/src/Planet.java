import java.io.ObjectInputStream;

public class Planet implements java.io.Serializable {
  int    order;
  String name;
  String nickname;
  double mass;

  public Planet(int order, String name, String nickname, double mass) {
    this.order    = order;
    this.name     = name;
    this.nickname = nickname;
    this.mass     = mass;
  }

  // this method will be called while printing the obj
  public String toString() {
    return order + ". " + name + " (" + nickname + "): " + mass;
  }

}
