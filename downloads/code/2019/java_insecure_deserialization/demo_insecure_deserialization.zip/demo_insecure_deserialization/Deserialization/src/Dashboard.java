import java.io.ObjectInputStream;

public class Dashboard implements java.io.Serializable {
    private double millage;
    private int miles_so_far;

    public Dashboard(double millage, int miles_so_far){
        this.millage = millage;
        this.miles_so_far = miles_so_far;
    }
    private void readObject(ObjectInputStream in) throws Exception{
        System.out.println("inside readObject() method of Dashboard !!");
        in.defaultReadObject();
    }

    public String toString() {
        return millage + " => " + miles_so_far;
    }
}
