import java.io.*;
import java.util.Base64;

public class BasicDosDeserialize {
    public static void main(String[] args) {
        // argument: base64 serialized obj as command line
        byte[] planetBytes = new byte[0];
        if (args[0].startsWith("rO0AB")) {
            planetBytes = Base64.getDecoder().decode(args[0].getBytes());
        } else {
            System.out.println("\nCaught an exception... Invalid object?\n");
            System.exit(0);
        }
        ByteArrayInputStream bIn = new ByteArrayInputStream(planetBytes);
        try {
            ObjectInputStream oIn = new ObjectInputStream(bIn);
            Planet planet = (Planet) oIn.readObject();  // actual deserialization
            oIn.close();
            bIn.close();
            System.out.println(planet);

        } catch (IOException | ClassNotFoundException e) {
            System.out.println();
            e.printStackTrace();
            System.out.println("\nCaught an exception... Invalid object?\n");
        }

    }
}
