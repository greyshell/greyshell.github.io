public class User implements java.io.Serializable {
  private String name;
  private final String nickname;
  static int uid;
  private transient String password;
  private double weight;
  private Car c;

  public User(String name, String nickname, int uid, String password, double weight) {
    this.name = name;
    this.nickname = nickname;
    this.uid = uid;
    this.password = password;
    this.weight = weight;
  }

  public User(String name, String nickname, int uid, String password, double weight, Car c) {
    this.name = name;
    this.nickname = nickname;
    this.uid = uid;
    this.password = password;
    this.weight = weight;
    this.c = c;
  }

  // this method will be called while printing the object
  public String toString() {
    return "name: " + name + ", " + "nickname: " + nickname + ", " + "uid: " + uid + ", " + "password: " + password + ", " + "weight: " + weight + ", " + "Car Object: " + c + " ";
  }
}
