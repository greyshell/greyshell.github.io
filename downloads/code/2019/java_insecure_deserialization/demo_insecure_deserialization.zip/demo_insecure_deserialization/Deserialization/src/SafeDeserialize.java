import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SafeDeserialize {
    public static void main(String[] args) {
        try {
            // fix 1: in current Java, by default enableUnsafeSerialization is set FALSE
            // it is blacklist based approach (i.e invokeTransformerMethod)and that can be bypassed by using new gadgets
            // enabling it by explicitly setting that true
            System.setProperty(
                    "org.apache.commons.collections.enableUnsafeSerialization",
                    "true");
            // file name of the deserialized object
            String fname = "../Serialization/bad_serialized_object.ser";
            FileInputStream fin = new FileInputStream(fname);
            // fix 2: whitelist based approach, resolve the class from the serialized object and
            Set whitelist = new HashSet<String>(Arrays.asList("User"));
            ObjectInputStream oin = new SafeObjectInputStream(fin, whitelist);

            /*
            Set rce_whitelist = new HashSet<String>(Arrays.asList("org.apache.commons.collections.bag.HashBag",
                    "org.apache.commons.collections.keyvalue.TiedMapEntry",
                    "org.apache.commons.collections.map.LazyMap",
                    "org.apache.commons.collections.functors.ChainedTransformer",
                    "[Lorg.apache.commons.collections.Transformer;",
                    "org.apache.commons.collections.functors.ConstantTransformer",
                    "java.lang.Runtime",
                    "org.apache.commons.collections.functors.InvokerTransformer",
                    "[Ljava.lang.Object;",
                    "[Ljava.lang.Class;",
                    "java.lang.String",
                    "java.lang.Object",
                    "[Ljava.lang.String;",
                    "java.lang.Integer",
                    "java.lang.Number",
                    "java.util.HashMap"));
            */
            // ObjectInputStream oin = new SafeObjectInputStream(fin, rce_whitelist);

            // expecting a Planet type obj, actual deserialization happens here
            User planet = (User) oin.readObject();
            oin.close();
            fin.close();
            System.out.println("\nThe object was read from " + fname + ":");
            System.out.println(planet);
            System.out.println();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
