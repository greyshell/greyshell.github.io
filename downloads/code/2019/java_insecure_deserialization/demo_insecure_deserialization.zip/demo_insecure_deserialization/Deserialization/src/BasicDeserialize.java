import java.io.*;

public class BasicDeserialize {
    public static void main(String[] args) {
        try {
            // fix 1: in current Java, by default enableUnsafeSerialization is set FALSE
            // it is blacklist based approach (i.e invokeTransformerMethod)and that can be bypassed by using new gadgets
            // enabling it by explicitly setting that true
            System.setProperty(
                    "org.apache.commons.collections.enableUnsafeSerialization",
                    "true");
            // control the file name of the deserialized object:
            // String fname = "../Serialization/serialized_object.ser";  // good object
            // String fname = "../Serialization/serialized_object02.ser";  // wrong object
            String fname = "../Serialization/bad_serialized_object.ser";  // evil object

            FileInputStream fin = new FileInputStream(fname);
            ObjectInputStream oin = new ObjectInputStream(fin);

            // expecting a User type obj, actual deserialization happens here
            User u = (User) oin.readObject();
            oin.close();
            fin.close();
            System.out.println("The object was read from " + fname + ":");
            System.out.println(u);
            System.out.println();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
