import java.io.ObjectInputStream;

public class Car implements java.io.Serializable{
    private String name;
    public String color;
    private transient String vin;
    static int price;
    private Dashboard dash;

    public Car(String name, String color, String vin, int price, Dashboard dash) {
        this.name = name;
        this.color = color;
        this.vin = vin;
        this.price = price;
        this.dash = dash;
    }

    private void readObject(ObjectInputStream in) throws Exception{
        System.out.println("inside readObject() method of Car !!");
        in.defaultReadObject();
        // perform some operation to change the state of the object
        this.color = "black";
    }
    // this method will be called while printing the object
    public String toString() {
        return name + " - " + color + " - " + vin + " - " + price + " - " + dash;
    }
}
