import java.lang.reflect.Method;
import java.lang.Runtime;

public class Concept02 {
    public static void main(String[] args) {
        try {
            // run a command using Java reflection API
            Class<Runtime> runtimeClass = Runtime.class;
            Method getRuntimeMethod = runtimeClass.getMethod("getRuntime"); // method name
            // example of invoke() method: connect the Class with Method along with params
            // similar to Runtime r = (Runtime) Runtime.getRuntime();
            Runtime r = (Runtime) getRuntimeMethod.invoke(null,null);
            // arg 1 => static class function -> null is passed instead of object
            // arg 2 => null means no argument
            r.exec("/usr/bin/gnome-calculator");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
