import org.apache.commons.collections.bag.HashBag;
import org.apache.commons.collections.keyvalue.TiedMapEntry;
import org.apache.commons.collections.map.LazyMap;
import org.mockito.internal.util.reflection.Whitebox;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class BuildConcept {
    public static void main(String[] args) {
        try {
            MyReverse a = new MyReverse();
            a.transform("AA");
            System.exit(0);
            // concept of HashMap
            // explicitly declare the data_type of key and value
            // HashMap<String, String> capitalCities = new HashMap<String, String>();  // method 1
            Map capitalCities = new HashMap();  // method 2: objective is to use this in LazyMap
            capitalCities.put("england", "london");
            System.out.println(capitalCities);
            System.out.println(capitalCities.get("england"));
            System.out.println(capitalCities.get("india"));

            // LazyMap: A type of 'Map' which creates a value if there’s no value for the requested key
            // This generation is done through a 'transformer' on the Key.
            Map lazyName = LazyMap.decorate(capitalCities, new MyReverse());
            System.out.println((String)lazyName.get("india"));
            System.exit(0);

            TiedMapEntry tidemapentry = new TiedMapEntry(lazyName, "foo");
            System.out.println(lazyName);

            // concept of HashBag
            HashBag h = new HashBag();
            //h.add(tidemapentry);
            //System.out.println(h);  // [1:foo=oof]
            //System.exit(0);

            h.add(new Object());

            Map internalMap = (Map) Whitebox.getInternalState(h, "map");
            Object[] nodesArray = (Object[]) Whitebox.getInternalState(internalMap, "table");
            Object node = Arrays.stream(nodesArray)
                    .filter(Objects::nonNull)
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("this can't happen"));
            //Whitebox.setInternalState(node, "key", tidemapentry);
            nodesArray[tidemapentry.hashCode()] = tidemapentry;
           // System.out.println(Whitebox.getInternalState(node, "value"));

            System.out.println(h); // [0:foo=oof]
            // underlying it executes the hashcode()
            System.exit(0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
