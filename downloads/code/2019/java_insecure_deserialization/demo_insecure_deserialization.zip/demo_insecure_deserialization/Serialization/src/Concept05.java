public class Concept05 {
    public static void main(String[] args) {
        try {
            MyReverse rev = new MyReverse();
            System.out.println(rev.transform("MyString"));  // calling the transform method

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
