import org.apache.commons.collections.Transformer;
import org.apache.commons.lang3.StringUtils;

public class MyReverse implements Transformer {
    public Object transform(Object o) {
        String name = (String) o;
        System.out.println("executing transform method !!");
        return StringUtils.reverse(name);
    }
}
